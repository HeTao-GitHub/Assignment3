package assignment3;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;
import java.util.Vector;
import java.util.ArrayList;

public class Main2014302580065 {
	
	

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
         String url="http://person.zju.edu.cn/dept-person-5-504000.html";
         String[] sufurl={"1620","1626","1610","1618","1614","1722","1723","1628","1569","1568"};
         Vector<String> urlset=new Vector<String>(20);
         Vector<String> urlset1=new Vector<String>(20);
         for(int i=0;i<sufurl.length;i++){
	     urlset.add(url+sufurl[i]);
         }
         for(int i=1589;i<1599;i++){
	     urlset1.add(url+i);
         }
       //���߳���ȡ
         Singlethreading2014302580065 s=new Singlethreading2014302580065(urlset);
         
       //���߳���ȡ
         Multithreading2014302580065 m=new Multithreading2014302580065(urlset1);
         
     }
}
//��jsoup��ȡ������teacher��ҳ
class Crawle2014302580065 {
	public String mname=null;
	public String mtelephone=null;
	public String memail=null;
	public String mintroduction=null;
	public static  Teainfo2014302580065 teacher_information=new Teainfo2014302580065();
	public static Connection conn=teacher_information.getConn();
	public static String sql;
	public static PreparedStatement pstatement=null;
	 int n=0;
	public void readHTML(String url) throws SQLException{       
		String myurl=url;
		try{ Document mydoc=Jsoup.connect(myurl).get();
		Elements elements1=mydoc.select("[class=about_info fn_left]");
	    Elements information=elements1.select("he");
	    String introduction=information.get(3).text();
	    String name=information.get(0).text();
	    String telephone=information.get(5).text();
	    String email=information.get(7).text();
	    this.mname=name;
	    this.mtelephone=telephone;
	    this.memail=email;
	    this.mintroduction=introduction;  
	   //д�����ݿ�
	    sql="insert into teacher_table(name,phone,email,introduction)values('"+this.mname+"','"+this.mtelephone+"','"+this.memail+"','"+this.mintroduction+"');";
	    pstatement=(PreparedStatement) conn.prepareStatement(sql);
	    pstatement.executeLargeUpdate(sql);
	    n++;
	    if(n>=20){
	    pstatement.close();
	    conn.close();}
	    }catch(IOException e){
			e.printStackTrace();}
	}
 }
//���߳���ȥ
class Singlethreading2014302580065 {
		private Crawle2014302580065 crawle=new Crawle2014302580065();
	public Singlethreading2014302580065(Vector<String> urlset) throws SQLException{
		Vector<String> myurl;
		myurl=urlset;
		long startTime=System.currentTimeMillis();
		for(int i=0;i<myurl.size();i++){
		String url=(String) myurl.get(i);
		crawle.readHTML(url);
			
		}
		
		long endTime=System.currentTimeMillis();
	    System.out.println("���߳���ȡ��ʱ"+(endTime-startTime));
	}
}
//���߳���ȥ
 class Multithreading2014302580065 {
		ArrayList<String> allurlset=new ArrayList<String>();
		ArrayList<String>notCrawleurlSet=new ArrayList<String>();
		int threadCount=20;
		int count=0;//�̴߳���wait״̬��������
		public static final Object signal=new Object();//�̼߳��źű���
		private Crawle2014302580065 crawle=new Crawle2014302580065();
		
	    public Multithreading2014302580065(Vector<String> urlsetl){
		for(int i=0;i<urlsetl.size();i++) {
			String url=(String) urlsetl.get(i);
			addUrl(url);
		};//��url ����
		long startTime=System.currentTimeMillis();
		begin();
		while(true){
			if(notCrawleurlSet.isEmpty()&&Thread.activeCount()==1||count==threadCount){
				long endTime=System.currentTimeMillis();
				System.out.println("���߳���ȡ��ʱ"+(endTime-startTime));
		        //System.exit(1);
				break;
			}
	           
		}
	}
	private void begin(){
		for(int i=0;i<threadCount;i++){
			new Thread(new Runnable(){
				public void run(){
					while(true){
						String aurl=getAUrl();
						if(aurl!=null){
				          
							try {
								crawle.readHTML(aurl);
							} catch (SQLException e) {
								
								e.printStackTrace();
							}
						}else{
							synchronized(signal){
								try{
									count++;
									signal.wait();	
								}catch(InterruptedException e){
									e.printStackTrace();
								}
							}
						}
					}
				}
			},"thread-"+i).start();
		}
	}
	public synchronized String getAUrl(){
	//	if(notCrawleurlSet.isEmpty()) return null;
	//	String tempAUrl;
	////	tempAUrl=notCrawleurlSet.get(0);
	//	notCrawleurlSet.remove(0);
	//	return tempAUrl;
	}
	public synchronized void addUrl(String url){
		notCrawleurlSet.add(url);
		allurlset.add(url);
	}
}
class Teainfo2014302580065 {
		public String url = "jdbc:mysql://localhost:3306/teacher_infornation";
	    public String driver = "com.mysql.jdbc.Driver";
	    Connection conn = null;
	    Statement stmt = null;
	    ResultSet rs = null;
	    String sql;
	    PreparedStatement pstatement=null;
	    public Connection getConn(){
	    	 try {
	             Class.forName(driver);
	             conn = (Connection) DriverManager.getConnection(url, "root", "htxqj999jxmysql");
	             stmt = conn.createStatement();
	                
	             //System.out.println("���ݿ����ӳɹ���");
	             } catch (ClassNotFoundException e) {
	                // System.out.println("���ݿ����������ڣ�");
	                 System.out.println(e.toString());             
	             } catch (SQLException e) {
	                 System.out.println("SQL����");
	                 System.out.println(e.toString());
	             } finally {
	            	
	             }
	             return conn;	
	    }
}





